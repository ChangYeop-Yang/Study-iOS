# CS193P-iOS10
![CS193P](https://raw.githubusercontent.com/DonQvixote/CS193P-iOS10/master/CS193P-iOS10.png)   
Stanford University Course [Developing iOS 10 Apps with Swift](https://itunes.apple.com/cn/course/developing-ios-10-apps-with-swift/id1198467120) is a classic course for start learning iOS development. This repo shows my codes and notes when I was watching iTunes U courses.


