//
//  TabelDetailViewController.swift
//  Calculate
//
//  Created by USER on 2018. 1. 30..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit
import Twitter

class TabelDetailViewController: UIViewController {

  @IBOutlet weak var userImage: UIImageView!
  @IBOutlet weak var userName: UILabel!
  @IBOutlet weak var detail: UILabel!
  @IBOutlet weak var date: UILabel!
  @IBOutlet weak var caption: UILabel!
  
  internal var twitter: Tweet?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    userName.text = twitter?.user.name
    detail.text = twitter?.description
    date.text = String(describing: twitter?.created)
    caption.text = twitter?.text
  }
  
  override func viewDidDisappear(_ animated: Bool) {
    super.viewDidDisappear(animated)
    
    dismiss(animated: true, completion: nil)
  }
}
