//
//  StackViewController.swift
//  Calculate
//
//  Created by USER on 2018. 1. 29..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit

var counting: Int = 0

class user {
  
  var name: String
  var address: String
  weak var copyUser: user?
  
  init(name: String, address: String) {
    self.name = name
    self.address = address
    
    counting += 1
    print("Counting: \(counting)")
  }
  
  deinit {
    counting -= 1
    print("Counting: \(counting)")
  }
}

class StackViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

      var user1: user? = user(name: "YCY", address: "GIL")
      user1?.copyUser = user1
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
