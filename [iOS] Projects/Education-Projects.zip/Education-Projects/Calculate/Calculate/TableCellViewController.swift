//
//  TableCellViewControllerTableViewCell.swift
//  Calculate
//
//  Created by USER on 2018. 1. 30..
//  Copyright © 2018년 USER. All rights reserved.
//

import Twitter
import UIKit

class TableCellViewController: UITableViewCell {
  
  @IBOutlet weak var indicator: UIActivityIndicatorView! {
    didSet {
      indicator.startAnimating()
    }
  }
  @IBOutlet weak var title: UILabel!
  @IBOutlet weak var caption: UILabel!
  @IBOutlet weak var detail: UILabel!
  @IBOutlet weak var picture: UIImageView!
  
  internal var tweet: Tweet? {
    didSet { updateUI() }
  }
  
  private func updateUI() {
    
    detail.text = tweet?.text
    title.text = tweet?.user.name
    
    if let profileImageURL = tweet?.user.profileImageURL {
      DispatchQueue.global(qos: .userInitiated).async { [weak weakSelf = self] in
        if let imageData = try? Data(contentsOf: profileImageURL) {
          weakSelf?.imageView?.image = UIImage(data: imageData)
          weakSelf?.indicator.stopAnimating()
        }
      }
      
    } else {
      picture.image = #imageLiteral(resourceName: "download")
    }
    
    if let created = tweet?.created {
      let formatter = DateFormatter()
      if Date().timeIntervalSince(created) > 24*60*60 {
        formatter.dateStyle = .short
      } else {
        formatter.timeStyle = .short
      }
      caption.text = formatter.string(from: created)
    } else {
      caption.text = nil
    }
    
  }
  
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
  }
}
