//
//  TabelTableViewController.swift
//  Calculate
//
//  Created by USER on 2018. 1. 30..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit
import Twitter

class TabelTableViewController: UITableViewController, UITextFieldDelegate {
  
  private var tweets = [Array<Tweet>]()
  private var lastTwitterRequest: Request?
  
  private var searchText: String? {
    
    didSet {
      searchTextFiled.text = searchText
      searchTextFiled.resignFirstResponder()
      tweets.removeAll()
      tableView.reloadData()
      searchForTweets()
      title = searchText
    }
  }
  @IBOutlet weak var searchTextFiled: UITextField! {
    didSet {
      searchTextFiled.delegate = self
    }
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    tableView.rowHeight = UITableViewAutomaticDimension
    tableView.estimatedRowHeight = 100
  }
  
  private func twitterRequest() -> Request? {
    
    if let query = searchText, !query.isEmpty {
      return Request(search: query, count: 100)
    }
    
    return nil
  }
  
  private func searchForTweets() {
  
    if let request = twitterRequest() {
      lastTwitterRequest = request
      request.fetchTweets { [weak weakSelf = self] (newTweets) in
        
        DispatchQueue.main.async {
          if request == weakSelf?.lastTwitterRequest {
            weakSelf?.tweets.insert(newTweets, at: 0)
            weakSelf?.tableView.insertSections([0], with: .fade)
          }
        }
        
      }
    }
  }
  
  // MARK: - Table view data source
  override func numberOfSections(in tableView: UITableView) -> Int {
    // #warning Incomplete implementation, return the number of sections
    return tweets.count
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    // #warning Incomplete implementation, return the number of rows
    return tweets[section].count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "TabelCell", for: indexPath) as! TableCellViewController
    
    let tweetContent: Tweet = tweets[indexPath.section][indexPath.row]
    cell.tweet = tweetContent
    
    return cell
  }
  
  // MARK: - Table Delegate
  override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    performSegue(withIdentifier: "ActionSugue", sender: indexPath)
  }
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
    if let view = segue.destination as? TabelDetailViewController, let index = sender as? IndexPath {
      view.twitter = tweets[index.section][index.row]
    }
    
  }

  // MARK: - TextFiled Delegate
  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    if textField == searchTextFiled {
      searchText = searchTextFiled.text
    }
    return true
  }
}
