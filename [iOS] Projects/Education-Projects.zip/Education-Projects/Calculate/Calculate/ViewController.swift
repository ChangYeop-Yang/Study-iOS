//
//  ViewController.swift
//  Calculate
//
//  Created by USER on 2018. 1. 22..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit

var controllerCount = 0

class User {
  var name: String
  
  init(name: String) {
    self.name = name
    print("User \(name) is initialized")
  }
  
  deinit {
    print("User \(name) is being deallocated")
  }
}

let user1 = User(name: "John")

class ViewController: UIViewController {

  @IBOutlet weak var display: UILabel!
  
  private var brain = CalculatorBrain()
  
  var userIsInTheMiddleOfTyping = false
  
  var displayValue: Double {
    get {
      return Double(display.text!)!
    }
    
    set {
      display.text = String(newValue)
    }
  }
  
  override func viewWillLayoutSubviews() {
    super.viewWillLayoutSubviews()
    print("ASD")
  }
  
  override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
    print("QWE")
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    print(self.view.subviews.count)
    
    controllerCount += 1
    print("Controller Count = \(controllerCount)")
    
    brain.addUnaryOperation(symbol: "Z") { [weak mySelf = self] in
      mySelf?.display.textColor = UIColor.red
      return sqrt($0)
    }
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  deinit {
    
    controllerCount -= 1
    print("Controller Count = \(controllerCount)")
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }

  @IBAction func touchDigit(_ sender: UIButton) {
    
    let digit = sender.currentTitle!
    if userIsInTheMiddleOfTyping {
      let textCurrentlyInDisplay = display.text
      display.text = textCurrentlyInDisplay! + digit
    } else {
      display.text = digit
      userIsInTheMiddleOfTyping = true
    }
  }
  
  @IBAction func perfromOperation(_ sender: UIButton) {
  
    if userIsInTheMiddleOfTyping {
      brain.setOperand(operand: displayValue)
      userIsInTheMiddleOfTyping = false
    }
    
    if let mathematicalSymbol = sender.currentTitle {
      
      brain.performOperation(symbol: mathematicalSymbol)
    }
    
    displayValue = brain.result
  }
  
}
