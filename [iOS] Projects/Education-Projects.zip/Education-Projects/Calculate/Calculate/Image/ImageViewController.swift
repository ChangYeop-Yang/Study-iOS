//
//  ImageViewController.swift
//  Calculate
//
//  Created by USER on 2018. 1. 26..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController
{
    var imageURL: NSURL? {
      didSet {
        
        image = nil
        if view.window != nil {
          fetchImage()
        }
        
      }
    }
  
    private var imageView = UIImageView()
  
    private var image: UIImage? {
      get {
          return imageView.image
      }
      set {
          imageView.image = newValue
          imageView.sizeToFit()
        
          scrollView?.contentSize = imageView.frame.size
      }
    }
  
  private func fetchImage() {
    if let url = imageURL {
      
      indicator.startAnimating()
      DispatchQueue.global(qos: .userInitiated).async {
        let imageData = NSData(contentsOf: url as URL)
        
          DispatchQueue.main.async { [weak mySelf = self] in
            mySelf?.image = UIImage(data: imageData! as Data)
            mySelf?.indicator.stopAnimating()
          }
        }
    }
  }
  
  @IBOutlet weak var scrollView: UIScrollView! {
    
    didSet {
      scrollView.contentSize = imageView.frame.size
      scrollView.delegate = self
      scrollView.minimumZoomScale = 0.03
      scrollView.maximumZoomScale = 1.0
    }
  }
  
  @IBOutlet weak var indicator: UIActivityIndicatorView!
  
    override func viewDidLoad() {
        super.viewDidLoad()

      scrollView.addSubview(imageView)
    }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    if image == nil {
      fetchImage()
    }
  }
  
}

extension ImageViewController: UIScrollViewDelegate {
  
  func viewForZooming(in scrollView: UIScrollView) -> UIView? {
    return imageView
  }
}
