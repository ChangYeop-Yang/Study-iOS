//
//  ViewController.swift
//  ViewLifeCycle
//
//  Created by USER on 2018. 1. 24..
//  Copyright © 2018년 USER. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
  @IBOutlet weak var swich: UIButton! {
    willSet {
      print("2. 넌 실행이 되니? (WillSet)")
    }
    didSet {
      print("3. 넌 어디서 실행이 되니? (DidSet)")
    }
  }
  
  override func awakeFromNib() {
    super.awakeFromNib()

    print("1. AwakeFromNib")
    
    if swich == nil {
      print("NULL POINT EXCEPTION ERROR")
    }
  }
  
  override func loadView() {
    super.loadView()
    
    print("4. LoadView, 컨트롤러가 관리하는 뷰를 만드는 역할")
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
  
    print("5. ViewDidLoad, 리소스를 초기화하거나 초기 화면을 구성하는 용도")
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    print("6. ViewWillAppear")
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    
    print("7. ViewDidAppear")
  }
  
  override func viewWillLayoutSubviews() {
    super.viewWillLayoutSubviews()
    
    print("8. ViewWillLayoutSubviews")
  }
  
  override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
    
    print("9. ViewDidLayoutSubviews")
  }
  
  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    
    print("10. ViewWillDisappear")
  }
  
  override func viewDidDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    
    print("11. ViewDidDisAppear")
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    
    print("12. 아야 메모리 아끼라!")
  }
}

